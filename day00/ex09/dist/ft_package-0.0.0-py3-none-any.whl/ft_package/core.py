def count_in_list(lst, item) -> int:
    """Count occurrences of item in lst."""
    return lst.count(item)
